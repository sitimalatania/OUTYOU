﻿CREATE TABLE [dbo].[outyou]
(
	[Kategori] CHAR(10) NOT NULL PRIMARY KEY, 
    [Jumlah_p] INT NOT NULL, 
    [Total_p] INT NOT NULL
)
