# OUTYOU

Nama: Siti Malatania <br />
NIM: 20/456380/TK/50510

# Deskripsi

OUTYOU adalah sebuah aplikasi pengingat pengeluaran berbasis console.Latar belakang dari pembuatan aplikasi ini adalah banyaknya orang yang tidak dapat mengontrol keuangan mereka. Fungsi utama aplikasi ini adalah untuk mengatur pengeluaran user. Pengatur pengeluaran diatur untuk waktu satu minggu saja. Didalam aplikasi akan dimasukkan jumlah transaksi yang dilakukan. Jumlah ini memiliki batas yang sudah diset dalam program yaitu 5 kali. Jika jumlah transaksi yang dilakukan lebih dari 5 kali maka tidak bisa melanjutkan proses selanjutnya. Pengatur pengeluaran ini akan menunjukkan apakah user hemat atau boros. Jika user melakukan transaksi selama 5 kali maka user termasuk boros. Jika User melakukan transaksi kurang dari 5 kali maka user termasuk hemat.

# Catatan
Untuk program yang sesuai buka file Outyou/Uts/Uts.sln
